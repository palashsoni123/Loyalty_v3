"use client"
import Button from '@mui/material/Button';

export default function Button_JoinNow() {

    return (
        <>
            <div className="buttonMUI_joinnowhome">
                <Button variant="contained">Join Now</Button>
            </div>
        </>
    )
}

