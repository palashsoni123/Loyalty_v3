"use client"

import Button from '@mui/material/Button';

export default function Button_RedeemPrimary() {

    return (
        <>
                <div className="buttonMUI_redeem">
                <Button variant="contained">Apply to Cart</Button>
                </div>
        </>
    )
}
