"use client"

import Button from '@mui/material/Button';

export default function ButtonMUI() {

    return (
        <>
            <div className="buttonMUI_fixedDiscount">
                <Button variant="contained">Redeem</Button>
            </div>
        </>
    )
}
