"use client"

import Button from '@mui/material/Button';

export default function Button_RedeemSecondary() {

    return (
        <>
            <div className="buttonMUI_save">
                <Button variant="contained">Save for Later</Button>
            </div>

        </>
    )
}
