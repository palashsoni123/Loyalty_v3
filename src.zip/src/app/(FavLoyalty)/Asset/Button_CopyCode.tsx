"use client"
import Button from '@mui/material/Button';

export default function Button_CopyCode() {

    return (
        <>
            <div className="buttonMUI_copycode">
                <Button variant="contained">Join Now</Button>
            </div>
        </>
    )
}

