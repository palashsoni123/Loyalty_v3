"use client"

import Button from '@mui/material/Button';

export default function ButtonBirthday() {

    return (
        <>
            <div className="buttonMUI_Birthday">
                <Button variant="contained">Submit</Button>
            </div>
        </>
    )
}
