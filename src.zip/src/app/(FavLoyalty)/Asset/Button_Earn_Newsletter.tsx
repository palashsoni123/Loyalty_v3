"use client"

import Button from '@mui/material/Button';

export default function ButtonMUI() {

    return (
        <>
        <div className="buttonMUI">
        <Button variant="contained">Collect 200 Points</Button>
        </div>
        </>
    )
}
